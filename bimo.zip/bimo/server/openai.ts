import OpenAI from "openai";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const openai = new OpenAI({ 
  apiKey: process.env.OPENAI_API_KEY || process.env.VITE_OPENAI_API_KEY || "" 
});

export async function generateChatResponse(message: string): Promise<string> {
  if (!openai.apiKey) {
    return "I'm sorry, but the OpenAI API key is not configured. Please make sure to set a valid API key in the environment variables.";
  }

  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: "You are a helpful AI assistant in a chat application. Provide useful, concise, and friendly responses."
        },
        {
          role: "user",
          content: message
        }
      ],
      max_tokens: 500,
    });

    return response.choices[0].message.content || "I'm sorry, I couldn't generate a response.";
  } catch (error: any) {
    console.error("Error calling OpenAI API:", error);
    
    // Handle rate limit or quota exceeded errors
    if (error?.status === 429) {
      return "I'm sorry, but the OpenAI API quota has been exceeded. Please check your OpenAI account and billing details.";
    }
    
    // Handle other API errors with specific messages
    if (error?.error?.type) {
      return `I encountered an issue: ${error.error.message || 'Unknown API error'}. Please try again later.`;
    }
    
    return "I'm having trouble connecting to my AI service. Please try again later.";
  }
}
