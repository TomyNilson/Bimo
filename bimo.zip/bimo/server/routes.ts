import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertUserSchema, insertMessageSchema } from "@shared/schema";
import { generateChatResponse } from "./openai";

export async function registerRoutes(app: Express): Promise<Server> {
  // Get current user
  app.get("/api/user", async (req: Request, res: Response) => {
    // Using IP address as user identifier for simplicity
    // In a real-world app, you would use sessions/authentication
    const ip = req.ip || req.socket.remoteAddress || "unknown";
    
    // Find user by IP identifier
    let user = await storage.getUserByIdentifier(ip);
    
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }
    
    return res.status(200).json({
      id: user.id,
      username: user.username
    });
  });

  // Create user (set username)
  app.post("/api/user", async (req: Request, res: Response) => {
    try {
      const ip = req.ip || req.socket.remoteAddress || "unknown";
      
      // Validate request body
      const validatedData = insertUserSchema.parse({
        ...req.body,
        identifier: ip // Add the IP as identifier
      });
      
      // Check if user already exists
      let user = await storage.getUserByIdentifier(ip);
      
      if (!user) {
        // Create new user with IP as identifier and chosen username
        user = await storage.createUser({
          username: validatedData.username,
          identifier: ip
        });
        
        // Add welcome message from assistant
        await storage.createMessage({
          userId: user.id,
          content: `Hello, ${validatedData.username}! I'm your AI assistant. How can I help you today?`,
          role: "assistant"
        });
      }
      
      return res.status(200).json({
        id: user.id,
        username: user.username
      });
    } catch (error) {
      console.error("Error creating user:", error);
      return res.status(400).json({ message: "Invalid user data" });
    }
  });

  // Get messages for current user
  app.get("/api/messages", async (req: Request, res: Response) => {
    try {
      const ip = req.ip || req.socket.remoteAddress || "unknown";
      const user = await storage.getUserByIdentifier(ip);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      const messages = await storage.getMessages(user.id);
      return res.status(200).json(messages);
    } catch (error) {
      console.error("Error fetching messages:", error);
      return res.status(500).json({ message: "Failed to fetch messages" });
    }
  });

  // Send a message
  app.post("/api/messages", async (req: Request, res: Response) => {
    try {
      const ip = req.ip || req.socket.remoteAddress || "unknown";
      const user = await storage.getUserByIdentifier(ip);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Validate request
      if (!req.body.content || typeof req.body.content !== "string") {
        return res.status(400).json({ message: "Message content is required" });
      }
      
      // Create user message
      const userMessage = await storage.createMessage({
        userId: user.id,
        content: req.body.content,
        role: "user"
      });
      
      // Generate AI response - no longer throws errors, returns friendly message instead
      const aiResponse = await generateChatResponse(req.body.content);
      
      // Save AI response
      const assistantMessage = await storage.createMessage({
        userId: user.id,
        content: aiResponse,
        role: "assistant"
      });
      
      return res.status(200).json({
        userMessage,
        assistantMessage
      });
    } catch (error) {
      console.error("Error processing message:", error);
      return res.status(500).json({ message: "Failed to process message" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
