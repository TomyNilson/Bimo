import { MessageCircle } from "lucide-react";

interface ChatHeaderProps {
  username: string;
}

export const ChatHeader = ({ username }: ChatHeaderProps) => {
  return (
    <header className="bg-white shadow-sm py-4 px-4 fixed top-0 left-0 right-0 z-10">
      <div className="max-w-3xl mx-auto flex justify-between items-center">
        <h1 className="text-xl font-semibold text-gray-800 flex items-center">
          <MessageCircle className="h-5 w-5 text-primary mr-2" />
          AI Chat
        </h1>
        <div className="flex items-center">
          <div className="w-2 h-2 rounded-full bg-green-500 mr-2"></div>
          <span className="text-sm font-medium">{username}</span>
        </div>
      </div>
    </header>
  );
};
