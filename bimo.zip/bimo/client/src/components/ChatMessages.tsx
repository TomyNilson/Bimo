import { useEffect, useRef } from "react";
import { Bot } from "lucide-react";
import { Message } from "@/types";

interface ChatMessagesProps {
  messages: Message[];
  isTyping: boolean;
  username: string;
}

export const ChatMessages = ({ messages, isTyping, username }: ChatMessagesProps) => {
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Auto-scroll to bottom when messages change or AI is typing
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, isTyping]);

  return (
    <div className="chat-messages h-full px-1 py-2 flex flex-col">
      {messages.length === 0 && !isTyping && (
        <div className="flex items-center justify-center h-full">
          <div className="text-center p-6 rounded-lg bg-secondary/30 max-w-md">
            <h3 className="text-lg font-semibold mb-2">Welcome to AI Chat</h3>
            <p className="text-sm text-muted-foreground">
              Start a conversation by typing a message below. The AI assistant is ready to help you!
            </p>
          </div>
        </div>
      )}
      {messages.map((message) => (
        <div 
          key={message.id} 
          className={`flex items-start mb-4 ${message.role === 'user' ? 'justify-end' : ''}`}
        >
          {message.role === 'assistant' && (
            <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center text-white flex-shrink-0">
              <Bot className="h-4 w-4" />
            </div>
          )}
          
          <div 
            className={`
              ${message.role === 'user' 
                ? 'mr-2 bg-secondary text-gray-800 rounded-tr-none' 
                : 'ml-2 bg-neutral text-gray-50 rounded-tl-none'
              } px-4 py-3 rounded-lg max-w-[85%] whitespace-pre-wrap shadow-sm
            `}
          >
            <p className="text-sm md:text-base break-words font-medium">{message.content}</p>
          </div>
          
          {message.role === 'user' && (
            <div className="w-8 h-8 rounded-full bg-indigo-100 flex items-center justify-center text-primary flex-shrink-0">
              <span className="font-medium text-sm">{username.charAt(0).toUpperCase()}</span>
            </div>
          )}
        </div>
      ))}
      
      {isTyping && (
        <div className="flex items-start mb-4">
          <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center text-white flex-shrink-0">
            <Bot className="h-4 w-4" />
          </div>
          <div className="ml-2 bg-neutral text-gray-50 px-4 py-2 rounded-lg rounded-tl-none max-w-[85%]">
            <div className="flex space-x-1">
              <div className="dot h-2 w-2 bg-gray-300 rounded-full animate-[typing_1.5s_infinite_0s]"></div>
              <div className="dot h-2 w-2 bg-gray-300 rounded-full animate-[typing_1.5s_infinite_0.3s]"></div>
              <div className="dot h-2 w-2 bg-gray-300 rounded-full animate-[typing_1.5s_infinite_0.6s]"></div>
            </div>
          </div>
        </div>
      )}
      
      <div ref={messagesEndRef} />
    </div>
  );
};
