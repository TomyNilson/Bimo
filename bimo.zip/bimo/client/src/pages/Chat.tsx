import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { getUsernameStatus, getChatHistory, sendMessage } from "@/lib/api";
import { UsernameModal } from "@/components/UsernameModal";
import { ChatHeader } from "@/components/ChatHeader";
import { ChatMessages } from "@/components/ChatMessages";
import { MessageInput } from "@/components/MessageInput";
import { useToast } from "@/hooks/use-toast";
import { Message } from "@/types";

export default function Chat() {
  const [username, setUsername] = useState<string | null>(null);
  const [showUsernameModal, setShowUsernameModal] = useState(false);
  const [isTyping, setIsTyping] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Check if user has set a username
  const { data: usernameStatus, isLoading: isCheckingUsername } = useQuery({
    queryKey: ['/api/user'],
    queryFn: getUsernameStatus,
    staleTime: Infinity,
  });

  // Fetch chat history
  const { 
    data: messages = [], 
    isLoading: isLoadingMessages,
    error: messagesError
  } = useQuery({
    queryKey: ['/api/messages'],
    queryFn: getChatHistory,
    enabled: !!username || (usernameStatus?.hasUsername === true),
  });

  // Send message mutation
  const { mutate, isPending: isSending } = useMutation({
    mutationFn: sendMessage,
    onMutate: async (content) => {
      setIsTyping(true);
      setError(null);
      
      // Optimistically add the user message to the UI
      const previousMessages = queryClient.getQueryData(['/api/messages']) as Message[];
      
      const newMessage: Message = {
        id: Date.now(),  // Temporary ID
        content: content,
        role: 'user',
        timestamp: new Date().toISOString(),
        userId: 0  // Placeholder
      };
      
      // Update the cache with the optimistic update
      queryClient.setQueryData(['/api/messages'], [...(previousMessages || []), newMessage]);
      
      // Return the previous messages so we can roll back if needed
      return { previousMessages };
    },
    onSuccess: () => {
      // On success, refresh the message list from the server
      queryClient.invalidateQueries({ queryKey: ['/api/messages'] });
    },
    onError: (err: any, _variables, context) => {
      // Display error message
      const errorMessage = err.message || "Failed to send message. Please try again.";
      setError(errorMessage);
      
      toast({
        title: "Error",
        description: errorMessage,
        variant: "destructive",
      });
      
      // If we have context, roll back to the previous state
      if (context?.previousMessages) {
        queryClient.setQueryData(['/api/messages'], context.previousMessages);
      }
    },
    onSettled: () => {
      setIsTyping(false);
    },
  });

  // Show username modal if user hasn't set a username
  useEffect(() => {
    console.log('Username check effect running:', {
      isCheckingUsername,
      usernameStatus,
      showUsernameModal
    });
    
    if (!isCheckingUsername) {
      if (usernameStatus?.hasUsername) {
        console.log('User has username:', usernameStatus.username);
        setUsername(usernameStatus.username);
        setShowUsernameModal(false);
      } else {
        console.log('User needs to set username');
        // Force the username modal to appear for new users
        setShowUsernameModal(true);
      }
    }
  }, [isCheckingUsername, usernameStatus]);

  const handleSendMessage = (content: string) => {
    // Clear previous errors when sending a new message
    setError(null);
    mutate(content);
  };

  const handleUsernameSet = (newUsername: string) => {
    setUsername(newUsername);
    setShowUsernameModal(false);
  };

  // Determine loading state
  const isLoading = isCheckingUsername || isLoadingMessages;

  if (isLoading && !showUsernameModal) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full"></div>
      </div>
    );
  }

  return (
    <div className="flex flex-col min-h-screen max-w-3xl mx-auto">
      {username && <ChatHeader username={username} />}
      
      <main className="flex-1 pt-20 pb-24 px-4 overflow-hidden flex flex-col">
        <div className="h-full overflow-y-auto">
          <ChatMessages 
            messages={messages} 
            isTyping={isTyping} 
            username={username || ''} 
          />
        </div>
      </main>
      
      <MessageInput 
        onSendMessage={handleSendMessage} 
        disabled={isSending || !username}
        error={error}
      />
      
      <UsernameModal 
        open={showUsernameModal} 
        onUsernameSet={handleUsernameSet} 
      />
    </div>
  );
}
