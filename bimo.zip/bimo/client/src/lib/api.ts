import { apiRequest } from "./queryClient";
import { Message } from "../types";

export async function getUsernameStatus() {
  try {
    console.log('Checking username status...');
    const response = await fetch('/api/user', {
      credentials: 'include',
    });
    
    if (response.status === 404) {
      console.log('User not found, needs to set username');
      return { hasUsername: false };
    }
    
    if (!response.ok) {
      console.error('API error:', response.status, response.statusText);
      throw new Error('Failed to check username status');
    }
    
    const data = await response.json();
    console.log('Username status:', data);
    return { hasUsername: true, username: data.username };
  } catch (error) {
    console.error('Error checking username status:', error);
    // Even if there's an error, we want new users to see the username modal
    return { hasUsername: false };
  }
}

export async function setUsername(username: string) {
  console.log('Setting username:', username);
  try {
    const response = await apiRequest('POST', '/api/user', { username });
    const data = await response.json();
    console.log('Username set successfully:', data);
    return data;
  } catch (error) {
    console.error('Error setting username:', error);
    throw error;
  }
}

export async function getChatHistory() {
  try {
    const response = await fetch('/api/messages', {
      credentials: 'include',
    });
    
    if (!response.ok) {
      throw new Error('Failed to fetch chat history');
    }
    
    return await response.json();
  } catch (error) {
    console.error('Error fetching chat history:', error);
    throw error;
  }
}

export async function sendMessage(content: string) {
  try {
    const response = await apiRequest('POST', '/api/messages', { content });
    return await response.json();
  } catch (error) {
    console.error('Error sending message:', error);
    // Throw a more specific error to be handled in the UI
    throw new Error('Failed to get response from AI. Please try again later.');
  }
}
