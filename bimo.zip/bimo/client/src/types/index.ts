export interface Message {
  id: number;
  content: string;
  role: 'user' | 'assistant';
  timestamp: string;
  userId?: number; // Making userId optional to match server model
}

export interface ChatState {
  messages: Message[];
  isTyping: boolean;
  error: string | null;
}
